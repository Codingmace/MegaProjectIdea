package ND;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob18 {

    public static void main(String[] args) throws Exception {
//        Problem: Musical Transposition
//        Points: 16
        Scanner scan = new Scanner(new File("prob18.txt"));
        String s = scan.nextLine(); // Target Instrument
        String sig = scan.nextLine(); // Key Signature
        System.out.println(s);
        System.out.println(sig);
        s = s.substring(s.indexOf(":"));
        sig = sig.substring(sig.indexOf(":"));
        while (scan.hasNext()) {
            String line = scan.nextLine();
            String notes[] = line.split("[ ]+");
        }
    }

}
