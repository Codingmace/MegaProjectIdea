
import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob01 {

    public static void main(String[] args) throws Exception {
//        Problem: X Litters of Ginger Soda
//        Subject: Math
//        Points: 2
        Scanner scan = new Scanner(new File("prob01.txt"));
        int a = scan.nextInt();
        double b = a / 3.785;
    }

}
