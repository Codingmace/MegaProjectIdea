package ND;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob06 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob06.txt"));
//        String a = scan.next();
//        int b = scan.nextInt();
//        scan.nextLine();
//        while (!"END".equals(a) && b != 0) {
//            scan.nextLine();
//            String c = scan.nextLine();
//            String d[] = c.split("\\s+");
//            int e[] = new int[d.length];
//            for (int i = 0; i < e.length; i++) {
//                e[i] = Integer.parseInt(d[i]);
//            }
//            int con = 0;
//            for (int i = 1; i < e.length - 1; i++) {
//                if (e[i - 1] <= e[i] && e[i] >= e[i + 1]) {
//                    System.out.println(a + " " + (i + 1) + ", " + b + " :" + e[i]);
////                    con++;
////                } else if (e[i - 1] <= e[i] && e[i] >= e[i + 1]) {
////                    con++;
//                } else if (con > 0) {
//                    System.out.println(a + " " + (i + 1) + " - " + (i + con + 1) + ", " + b + " :" + e[i]);
//                    con = 0;
//                }
//            }
//            a = scan.next();
//            b = scan.nextInt();
//        }

    }

}
