package ND;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob06 {

    public static void main(String[] args) throws Exception {
//        Problem: Heronian Rectangles
//        Points: 5
        Scanner scan = new Scanner(new File("prob06.txt"));
        int p = scan.nextInt(); // Perimeter
        int a = scan.nextInt(); // Area
        
    }
}
