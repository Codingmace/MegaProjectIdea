
/**
 *
 * @author Master Ward
 */
public class prob00 {

    public static void main(String[] args) throws Exception {
        System.out.println("Hello, Master. You're looking well today.");
    }

}
