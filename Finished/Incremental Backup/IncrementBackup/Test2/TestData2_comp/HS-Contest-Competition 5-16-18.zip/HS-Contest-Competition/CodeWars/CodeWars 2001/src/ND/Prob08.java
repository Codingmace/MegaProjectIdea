package ND;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob08 {

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob08.txt"));
        String fin = "";
        ArrayList<String> message = new ArrayList();
        while (scan.hasNext()) {
            String s = scan.nextLine();
            String split[] = s.split("[, ]+");
            for (int i = 0; i < split.length; i++) {
                message.add(split[i]);
            }
        }
    }
}
