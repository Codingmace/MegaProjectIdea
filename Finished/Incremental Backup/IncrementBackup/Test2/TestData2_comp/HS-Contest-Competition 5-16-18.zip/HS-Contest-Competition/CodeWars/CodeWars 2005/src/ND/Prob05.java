package ND;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob05 {

    public static void main(String[] args) throws Exception {
//        Problem: Text Me
//        Points: 5
        Scanner scan = new Scanner(new File("prob05.txt"));
        String s = scan.nextLine();
        String split[] = s.split("[ ]+");
        String codes[] = {"0", "@.?1", "ABC2", "DEF3", "GHI4", "JKL5", "MNO6", "PQRS7", "TUV8", "WXYZ9"};
        for (int i = 0; i < split.length; i++) {
            char ch[] = split[i].toCharArray();
            int con =0; // Counter
            while(con < ch.length){
                // Neeed to add the codes here
            }
        }
    }
}
