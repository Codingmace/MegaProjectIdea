package ND;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob08 {

    public static void main(String[] args) throws Exception {
//        Problem: CSI Crime Lab
//        Points: 8
        Scanner scan = new Scanner(new File("prob08.txt"));
        String s = scan.nextLine(); // <Suspects>
        String suspect = "";
        while (!s.equals("<Scene>")) {

        }
        while (!s.equals("<END>")) {

        }

        System.out.println("The suspect is: " + suspect);
    }
}
