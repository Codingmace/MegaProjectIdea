

import java.io.File;
import java.util.*;

/**
 *
 * @author Master Ward
 */
public class Prob11 {
//        Problem: Museum Area
//        Difficulty: Hard
//        Subject: Covex Polygon Area

    public static void main(String[] args) throws Exception {
        Scanner scan = new Scanner(new File("prob11.txt"));
        int numVertices = scan.nextInt(); // Number of verticies
        /* Store vertices in 2D array */
        vertex[] vertices = new vertex[numVertices + 1];
        for (int i = 0; i < numVertices; i++) {
            vertices[i] = new vertex();
            vertices[i].x = scan.nextDouble();
            vertices[i].y = scan.nextDouble();
        }
        /* Adding final Vertex */
        vertices[numVertices] = new vertex();
        vertices[numVertices].x = vertices[0].x;
        vertices[numVertices].y = vertices[0].y;
        numVertices++;
        /* Last vertex == first vertex */
        System.out.println(calArea(vertices, numVertices));
        scan.close();
    }

    /*
     * Calculate the area of a polygon
     * Formula: A = 1/2 * SUM[(x(i)y(i+1) - (x(i+1)y(i)] for all i.          
     * Nodes that are clockwise have a negative area.
     * (Still correct)
     */
    private static double calArea(vertex[] vertices, int num) {
        double d = 0.0;
        for (int i = 0; i < num - 1; i++) {
            d += ((vertices[i].x * vertices[i + 1].y) - (vertices[i + 1].x * vertices[i].y));
        }
        return Math.abs(0.5 * d);
    }
}

/* Easy way to keep track of vertex */
class vertex {

    double x, y;
}
