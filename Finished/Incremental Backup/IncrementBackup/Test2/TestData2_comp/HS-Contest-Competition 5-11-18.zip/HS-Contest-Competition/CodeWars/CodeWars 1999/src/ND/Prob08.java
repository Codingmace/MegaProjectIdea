package ND;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
/**
 * Needs to use path finding MAYBE
 */
public class Prob08 {

    public static void main(String[] args) throws Exception {
//        Problem: Traveling Salesperson
//        Points: 6
        Scanner scan = new Scanner(new File("prob08.txt"));
        
    }
}
