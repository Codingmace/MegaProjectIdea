package ND;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob14 {

    public static void main(String[] args) throws Exception {
//        Problem: Arithmetic Expression Evaluation
//        Points: 11
        Scanner scan = new Scanner(new File("prob14.txt"));
    }
}
