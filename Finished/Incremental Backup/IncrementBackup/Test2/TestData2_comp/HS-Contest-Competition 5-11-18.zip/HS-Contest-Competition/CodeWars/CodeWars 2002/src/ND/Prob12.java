package ND;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Master Ward
 */
public class Prob12 {

    public static void main(String[] args) throws Exception {
//        Problem: Server Blade Power Consumption
//        Points: 13
        Scanner scan = new Scanner(new File("prob12.txt"));
    }
}
